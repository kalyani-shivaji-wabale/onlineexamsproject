package com.example.onlineexamproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineexamprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
