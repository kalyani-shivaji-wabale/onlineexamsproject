package com.example.onlineexamproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineexamprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineexamprojectApplication.class, args);
	}

}
